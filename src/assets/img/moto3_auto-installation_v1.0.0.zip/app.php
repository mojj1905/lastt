<?php
header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Cache-Control: post-check=0, pre-check=0', false);
header('Pragma: no-cache');

echo '<!DOCTYPE html><head><meta http-equiv="refresh" content="0; url=./mt-install/" /></head><body></body>';
